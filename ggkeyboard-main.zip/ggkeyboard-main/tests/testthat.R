library(testthat)
library(ggkeyboard)

test_check("ggkeyboard")
